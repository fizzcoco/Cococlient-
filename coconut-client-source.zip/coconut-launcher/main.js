const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { Client } = require('minecraft-launcher-core');
const { Auth } = require('msmc');

const MC_VERSION = '1.21.11';
const ROOT = path.join(app.getPath('userData'), 'minecraft');

let win;
let session = null; // Minecraft auth session from msmc

function log(msg) {
  if (win && !win.isDestroyed()) win.webContents.send('log', String(msg));
}

async function getJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.json();
}

async function download(url, dest) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, Buffer.from(await res.arrayBuffer()));
}

/** Installs the Fabric loader profile for MC_VERSION; returns its version id. */
async function installFabric() {
  const loaders = await getJson(`https://meta.fabricmc.net/v2/versions/loader/${MC_VERSION}`);
  if (!loaders.length) throw new Error(`No Fabric loader for ${MC_VERSION}`);
  const loaderVer = loaders[0].loader.version;
  const profile = await getJson(
    `https://meta.fabricmc.net/v2/versions/loader/${MC_VERSION}/${loaderVer}/profile/json`);
  const dir = path.join(ROOT, 'versions', profile.id);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, `${profile.id}.json`), JSON.stringify(profile));
  return profile.id;
}

/** Downloads Fabric API from Modrinth and copies the Coconut mod into /mods. */
async function installMods() {
  const modsDir = path.join(ROOT, 'mods');
  fs.mkdirSync(modsDir, { recursive: true });

  if (!fs.readdirSync(modsDir).some(f => f.startsWith('fabric-api'))) {
    log('Downloading Fabric API...');
    const q = `game_versions=${encodeURIComponent(JSON.stringify([MC_VERSION]))}` +
              `&loaders=${encodeURIComponent(JSON.stringify(['fabric']))}`;
    const versions = await getJson(`https://api.modrinth.com/v2/project/fabric-api/version?${q}`);
    if (!versions.length) throw new Error('No Fabric API build found for this version');
    const file = versions[0].files.find(f => f.primary) || versions[0].files[0];
    await download(file.url, path.join(modsDir, file.filename));
  }

  // Your built mod jar: put it in /resources/coconutclient.jar before packaging.
  const resDir = app.isPackaged ? path.join(process.resourcesPath, 'resources')
                                : path.join(__dirname, 'resources');
  const jar = path.join(resDir, 'coconutclient.jar');
  if (fs.existsSync(jar)) {
    fs.copyFileSync(jar, path.join(modsDir, 'coconutclient.jar'));
  } else {
    log('WARNING: resources/coconutclient.jar not found, launching without the Coconut mod.');
  }
}

ipcMain.handle('login', async () => {
  const authManager = new Auth('select_account');
  const xbox = await authManager.launch('electron');
  session = await xbox.getMinecraft();
  return session.profile.name;
});

ipcMain.handle('play', async (_e, opts) => {
  if (!session) throw new Error('Log in first.');
  log('Preparing Fabric...');
  const versionId = await installFabric();
  await installMods();

  const launcher = new Client();
  launcher.on('progress', p => log(`Downloading ${p.type}: ${p.task}/${p.total}`));
  launcher.on('debug', d => log(d));
  launcher.on('data', d => log(d));
  launcher.on('close', code => log(`Game closed (exit code ${code})`));

  log('Launching Minecraft...');
  await launcher.launch({
    authorization: session.mclc(),
    root: ROOT,
    javaPath: opts.javaPath || 'java',  // Minecraft 1.21.x needs Java 21
    version: { number: MC_VERSION, type: 'release', custom: versionId },
    memory: { max: `${opts.ramGb || 4}G`, min: '2G' },
  });
});

app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 900,
    height: 560,
    resizable: false,
    title: 'Coconut Client',
    backgroundColor: '#14110f',
    webPreferences: { preload: path.join(__dirname, 'preload.js') },
  });
  win.setMenuBarVisibility(false);
  win.loadFile('index.html');
});

app.on('window-all-closed', () => app.quit());
