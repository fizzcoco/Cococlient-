const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('coconut', {
  login: () => ipcRenderer.invoke('login'),
  play: opts => ipcRenderer.invoke('play', opts),
  onLog: cb => ipcRenderer.on('log', (_e, msg) => cb(msg)),
});
